
<!DOCTYPE html>
<html>
<head>
    <title>Italian VAT Checker</title>
</head>
<body>
    <h1>Upload Italian VAT CSV</h1>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <input type="submit" value="Start Validation">
    </form>
    <br>
    <a href="vat_test_form.php">Or Test a Single VAT Number</a>
</body>
</html>
